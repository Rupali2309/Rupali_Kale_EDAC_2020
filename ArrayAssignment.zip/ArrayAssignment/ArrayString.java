package ArrayAssignment;

import java.util.Arrays;


class ArrayString
{
public static void main(String[] args) {
		
		String[] arrayString = new String[] { "one","two","three","four","five"};
	
		
                    System.out.println(Arrays.toString(arrayString));
                    
                

			
}
}