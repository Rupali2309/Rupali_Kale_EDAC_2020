public class Stud
{
public static void main(String []args)
{
int rollNo=100;
System.out.println(rollNo=100);
}
}