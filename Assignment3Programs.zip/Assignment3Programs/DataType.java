
public class DataType
{
   static boolean val1;
   static double val2;
   static float val3;
   static int val4;
   static long val5;
   static String val6;
public static void main(String []args)
   {
      System.out.println("Default values.....");
      System.out.println("Val1 = " + val1);
      System.out.println("Val2 = " + val2);
      System.out.println("Val3 = " + val3);
      System.out.println("Val4 = " + val4);
      System.out.println("Val5 = " + val5);
      System.out.println("Val6 = " + val6);
   }

}
