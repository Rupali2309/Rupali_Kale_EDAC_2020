class TypeCasting
{
public static void main(String []args)
{
int x=10;
double y=x;
System.out.println(y); //Widening  type casting

double a=50.0;
x=(int)a;
System.out.println(x);

}
}