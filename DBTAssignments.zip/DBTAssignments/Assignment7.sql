CREATE DATABASE ASSIGNMENT7;
USE ASSIGNMENT7;
CREATE TABLE Ord_master( 
Ord_no INT not null , 
Cust_cd char(20), 
status char(20)
);

ALTER table Ord_master ADD PRIMARY KEY (Ord_no);

ALTER TABLE Ord_master DROP PRIMARY KEY;
CREATE TABLE Ord_dtl(
Ord_no int ,Prod_cd char(10), Qty int (10),
 foreign key(Ord_no) references Ord_master(Ord_no)
);
alter table Ord_dtl add primary key(Prod_cd);

create table Prod_master(
Prod_cd char(20),
Prod_name char(30),
Qty_in_stock int(30),
Booked_qty int(30),
foreign key(Prod_cd) references Ord_dtl(Prod_cd)
);
INSERT INTO Ord_master VALUES(1,'C1','P');
INSERT INTO Ord_dtl VALUES(1,'P1',100);
INSERT INTO Ord_dtl VALUES(1,'P2',200);
INSERT INTO Ord_dtl VALUES(1,'P3',300);

INSERT INTO Prod_master VALUES('P1','FLOPPIES',10000,1000);
INSERT INTO Prod_master VALUES('P2','PRINTERS',5000,600);
INSERT INTO Prod_master VALUES('P3','MODEMS',3000,200);



/*1. Write a Before Insert trigger on Ord_dtl. Anytime a row is inserted in Ord_dtl, the
Booked_qty in Prod_master should be increased accordingly.*/
DELIMITER $$
CREATE TRIGGER  QUE1
BEFORE INSERT
ON Ord_dtl
FOR EACH ROW
BEGIN
UPDATE Prod_master SET Booked_qty=Booked_qty + NEW.Qty WHERE  Prod_cd=NEW.Prod_cd;

END $$

insert into Ord_dtl values(1,'P4',400);

SELECT * FROM Ord_dtl;
SELECT * FROM Prod_master;

DELETE FROM Ord_dtl WHERE Qty=100;


/*. Write a Before Delete trigger on Ord_dtl. Anytime a row is deleted from Ord_dtl, the
Booked_qty in Prod_mastershould be decreased accordingly.*/
DELIMITER $$
CREATE TRIGGER QUE2
BEFORE DELETE
ON Ord_dtl
FOR EACH ROW
BEGIN
UPDATE Prod_master SET Booked_qty=Booked_qty - OLD.Qty WHERE  Prod_cd=OLD.Prod_cd;
END $$
SELECT * FROM  Ord_dtl;
SELECT * FROM Prod_master;




DELIMITER $$
CREATE TRIGGER befdel_Ord_dtl BEFORE DELETE ON Ord_dtl
FOR EACH ROW
BEGIN
UPDATE Prod_master SET Booked_qty=Booked_qty-OLD.Qty WHERE Prod_cd=Prod_cd;
END $$

