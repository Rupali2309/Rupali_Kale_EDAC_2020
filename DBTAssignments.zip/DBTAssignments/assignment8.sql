CREATE DATABASE ASSIGNMENT8;
USE ASSIGNMENT8;
USE ASSIGNMENT5;
DROP DATABASE ASSIGNMENT8;


-- 1.	Write a Procedure that displays names and salaries of all Analysts recorded in the “emp” table by making use of a cursor.

DESC EMPLOYEE;
SELECT * FROM EMPLOYEE23;
SELECT * FROM EMP;

 DELIMITER $$
CREATE PROCEDURE DISPLAY_DETAILS()
BEGIN 
DECLARE HIGHEST_SAL INT;
DECLARE EMPNAME VARCHAR(20);
DECLARE DISPLAY CURSOR FOR SELECT ENAME,SAL FROM EMP;
OPEN DISPLAY;
FETCH DISPLAY INTO EMPNAME,HIGHEST_SAL;
SELECT ENAME ,SAL FROM EMP WHERE JOB='ANALYST';
CLOSE DISPLAY;
END $$
CALL DISPLAY_DETAILS();



-- 2.	Write a Procedure to display top 5 employees based on highest salary and display employee number, employee name and salary using Cursor.

DELIMITER @@
CREATE PROCEDURE DISPLAY_TOP_SAL()
BEGIN
DECLARE SALARY INT;
DECLARE EMPNAME VARCHAR(20);
DECLARE ENO INT;
DECLARE DISPLAY CURSOR FOR SELECT EMPNO,ENAME,SAL FROM EMP;
OPEN DISPLAY;
FETCH DISPLAY INTO ENO,EMPNAME,SALARY ;
SELECT EMPNO,ENAME ,SAL FROM EMP ORDER BY SAL DESC LIMIT 5;
CLOSE DISPLAY;
END @@

CALL DISPLAY_TOP_SAL()

-- 3.	Write  a procedure to display the concatenated first_name and last_name from “emp” table using cursors handle the  errors with Exit handler


DELIMITER !!
CREATE PROCEDURE DISPLAY_DATA()
BEGIN
DECLARE FIRST_NAME VARCHAR(50);
DECLARE LAST_NAME VARCHAR(50);
DECLARE FINISHED INTEGER DEFAULT 0;
DECLARE DISPLAY CURSOR FOR SELECT FIRST_NAME,LAST_NAME FROM EMP;
DECLARE EXIT HANDLER FOR NOT FOUND SET FINISHED = 1;
OPEN DISPLAY;

GETNAME: LOOP
FETCH DISPLAY INTO  FIRST_NAME,LAST_NAME;
IF FINISHED =1 THEN
LEAVE GETNAME;
END IF;
SELECT CONCAT (ENAME,LNAME)AS  FULLNAME FROM EMP;
END LOOP GETNAME;
CLOSE DISPLAY;
END !!
SELECT * FROM EMP;
CALL DISPLAY_DATA();


-- 4.	Write a procedure which select all the data from employee table and display the data of employee where employee name is ‘Manish’ using cursors.

DROP PROCEDURE DISPLAY_EMPLOYEE_DATA;
DELIMITER $$
CREATE PROCEDURE DISPLAY_EMPLOYEE_DATA()
BEGIN
DECLARE ENO INT ;
DECLARE  EMPNAME VARCHAR(30);
DECLARE EMP_JOB VARCHAR(30);
DECLARE EMP_MGR DECIMAL(4,0);
DECLARE EMP_HIREDATE DATE;
DECLARE EMP_SAL DECIMAL(7,2);
DECLARE DEPT_NO DECIMAL(2,0);
DECLARE DISPLAY CURSOR FOR SELECT * FROM EMP;
OPEN DISPLAY;
FETCH DISPLAY INTO ENO,EMPNAME,EMP_JOB,EMP_MGR,EMP_HIREDATE,EMP_SAL,DEPT_NO;
SELECT * FROM EMP WHERE ENAME='MANISH';
CLOSE DISPLAY;
END$$

CALL DISPLAY_EMPLOYEE_DATA();

-- 5.	Write a procedure which select delete the data from employee table if emp sal is less than 10000  using cursor and handle the  Sqlexception with continue handler
drop procedure details
delimiter &&
create procedure details()
begin
declare empno int;
declare empname varchar(30);
declare emp_job varchar(20);
declare emp_mgr decimal(4,0);
declare emp_hiredate date;
declare emp_sal decimal(7,2);
declare dept_no decimal(2,0);
declare finished integer default 0;

declare display cursor for select * from emp ;
declare continue handler for SQLException set finished = 1 ;

open display ;
	
		fetch display into empno,empname,emp_job,emp_mgr,emp_hiredate,emp_sal,dept_no;
	
             delete from emp where sal < 1000;
			
close display ;
end &&
delimiter ;

select * from emp ;
call details();




