//package Treepack;
//import java.util.Scanner;
//
//
//
//class BinaryNode
//{
//    BinaryNode left,right;
//    int data;
//
//    public BinaryNode()
//    {
//        left=null;
//        right=null;
//        data=0;
//    }
//    public BinaryNode(int n)
//    {
//        left=null;
//        right=null;
//        data=n;
//    }
//
//    public void setLeft(BinaryNode n) //set left node
//    {
//        left = n;
//
//    }
//    public void setRight(BinaryNode n) // set right node
//    {
//        right=n;
//    }
//
//    public BinaryNode getLeft()
//    {
//        return left;
//
//    }
//    public BinaryNode getRight() //get right node
//    {
//        return right;
//    }
//
//
//    public void setData(int d) //set data to node
//    {
//        data = d;
//    }
//    public int getData()   //get data from node
//    {
//        return data;
//    }
//
//
//}
//
//
//
//public class BinarySearch_1 {
//
//    private BinaryNode root;
//
//    BinarySearch_1() {
//
//        root = null;
//    }
//
//    public boolean isEmpty() {
//        return root == null;
//    }
//
//    public void insert(int data) {
//        root = insert(root, data);
//    }
//
//
//    private BinaryNode insert(BinaryNode node,int  data) {
//        if (node == null) {
//            node = new BinaryNode(data);
//
//        } else {
//            if (data <= node.getData()) {
//                node.left = insert(node.left, data);
//            } else {
//                node.right = insert(node.right, data);
//            }
//            return node;
//        }
//
//        public void delete(int k)
//        {
//            if (isEmpty())
//                System.out.println("Tree empty");
//            else if (search(k) == false)
//                System.out.println("Sorry" + k + "is not present");
//            else {
//                root = delete(root, k);
//                System.out.println(k + "deleted from the tree");
//            }
//        }
//        private BinaryNode delete(BinaryNode root,int k)
//        {
//            BinaryNode p,p2,n;
//            if(root.getData()==k) {
//                BinaryNode lt, rt;
//
//                lt = root.getLeft();
//                rt = root.getRight();
//                if (lt == null && rt == null)
//                    return null;
//                else if (rt == null) {
//                    p = lt;
//                    return p;
//                } else {
//                    p2 = rt;
//                    p = rt;
//                    while (p.getLeft() != null)
//                        p = p.getLeft();
//                    p.setLeft(lt);
//                    return p2;
//                }
//            }
//
//            if(k < root.getData())
//            {
//                n=delete(root.getLeft(),k);
//                root.setLeft(n);
//            }
//            else
//            {
//                n=delete(root.getRight(),k);
//                root.setRight(n);
//            }
//            return root;
//
//
//            }
//        public int countNodes()
//        {
//            return countNodes(root);
//        }
//        private int countNodes(BinaryNode r)
//
//
//
//        }
//
//
//        }
//
//    }
//
//}
//
//
//
//
