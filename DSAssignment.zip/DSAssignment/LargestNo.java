package DataStructurepack;
import java.util.Scanner;

public class LargestNo {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the three numbers:");
        int number1= sc.nextInt();
        float number2= sc.nextFloat();
        double number3=sc.nextDouble();

        double temp=(number1>number2 ?number1:number2);
        double largest=(temp>number3?temp:number3);

        System.out.println("Largest number is:"+largest);

    }


}
