package DSArraypack;

public class StackDemo {

        int top=-1;
        int size=5;
        int []stack=new int[size];
        void push(int ele) {
            if(isFull())
            {
                System.out.println("Stack is full");
            }
            else
            {
                ++top;
                stack[top]=ele;
                System.out.println("Element Pushed sucessfully");
            }
        }
        void pop() {
            if(isEmpty())
            {
                System.out.println("Stack is Empty,cant pop");

            }
            else
            {
                int ele=stack[top];
                --top;
                System.out.println(ele+" Poped sucessfully");
            }
        }
        boolean isFull() {
            if(top==(size-1))
            {
                return true;
            }
            return false;

        }
        boolean isEmpty() {
            if(top==-1)
            {
                return true;
            }
            return false;

        }
        void display() {
            System.out.print("Your Stack is ");
            for (int x=0;x<stack.length-1;x++) {
                System.out.print(stack[x] + " ");
            }
        }

        public static void main(String[] args) {
            StackDemo s=new StackDemo();
            s.push(10);
            s.push(100);
            s.push(102);

            s.push(103);
            s.push(105);
            s.pop();
            //s.push(106);
            s.display();
        }

    }
