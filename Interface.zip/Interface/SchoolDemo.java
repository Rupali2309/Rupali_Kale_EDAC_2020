package InterfaceDemo;

public class SchoolDemo
{
public static void main(String []args)
{
Student s=new Student(1,"rup","comp");
s.showDetail();

Teacher t=new Teacher(12,"nm","comp");
t.showDetail();
}

}