package JavaAssignment;

class Number
{
public static void main(String []args)
{

   // 
            

}

}