package JavaMiniProject;

import java.util.ArrayList;
 class Administrator extends Examination {
	public boolean setExaminationPaper(Registration user) {
		if (!user.isAdminUser()) {
			System.err.println("Failed to set examination paper as passed user is not Admin User");
			return false;
		}

		ArrayList<String> subjects = new ArrayList<>();
		System.out.println("Enter number of subjects");
		int total_subjects = Integer.parseInt(sc.nextLine());
		for (int i = 1; i <= total_subjects; i++) {
			System.out.println("Enter Subject Name :");
			subjects.add(sc.nextLine());
		}

		System.out.println("You have entered total " + total_subjects + " subjects are as follows");
		System.out.println(subjects);

		for (int counter = 0; counter < subjects.size(); counter++) {
			boolean repeat = true;
			ArrayList<String> questions = new ArrayList<>();
			ArrayList<String> answers = new ArrayList<>();

			System.out.println("Setting Question Paper for subject : " + subjects.get(counter));

			ArrayList<ArrayList<String>> choices = new ArrayList<>();
			while (repeat) {
				System.out.println("Select question type\n1. Multiple Choice Question\n2. Boolean Question");
				int ch = Integer.parseInt(sc.nextLine());

				System.out.println("Enter question : ");
				String question = sc.nextLine();

				ArrayList<String> choice = new ArrayList<>();
				if (ch == 1) {
					for (int i = 1; i <= 4; i++) {
						System.out.println("Enter option number : " + i);
						choice.add(sc.nextLine());
					}
				} else if (ch == 2) {
					choice.add("True");
					choice.add("False");
				}

				choices.add(choice);

				System.out.println(question);
				for (int i = 1; i <= choice.size(); i++)
					System.out.println(i + ". " + choice.get(i - 1));
				System.out.print("Select Correct Choice : ");
				ch = Integer.parseInt(sc.nextLine());
				answers.add(choice.get(ch - 1));

				questions.add(question);

				System.out.println("Do you want to enter more questions?? Press Y/y to Yes or Press N/n to No");
				if (sc.nextLine().trim().equalsIgnoreCase("n"))
					break;
			}

			System.out.println("Questions has been set successfully for subject " + subjects.get(counter));

			hmap_questions.put(subjects.get(counter), questions);
			hmap_answers.put(subjects.get(counter), answers);
			hmap_choices.put(subjects.get(counter), choices);
		}

		return true;
	}

	public void addStudent(Registration rg) {
		rg.doRegistration();
	}

	public void removeStudent() {
		System.out.println("Enter Student Name : ");
		String studentName = sc.nextLine();
		boolean studentRemoved = false;

		for (Registration registeredUser : Registration.registeredUsers) {
			if (registeredUser.getName().equals(studentName)) {
				studentRemoved = registeredUser.registeredUsers.remove(registeredUser);
			}
		}
		if (studentRemoved)
			System.out.println("Successfully Removed Student " + studentName);
		else
			System.err.println("Failed to remove student : " + studentName);
	}
}
