package JavaMiniProject;

import java.util.ArrayList;
import java.util.HashMap;

public class Examination extends ExaminationMgmtSystem {

	protected static HashMap<String, ArrayList<String>> hmap_questions = new HashMap<>();    // hashmap stores string as key and arraylist As a value
	protected static HashMap<String, ArrayList<String>> hmap_answers = new HashMap<>();
	protected static HashMap<String, ArrayList<ArrayList<String>>> hmap_choices = new HashMap<>();

	protected static HashMap<String, ArrayList<String>> hmap_StudentAnswers = new HashMap<>();

	public void viewStudentResult(String studentName) {
		System.out.println("In View Result");
		if (hmap_StudentAnswers.size() == 0)
			System.err.println("Result not Found");
		else {
			for (String subject : hmap_StudentAnswers.keySet()) {
				System.out.println("Calculating percentage of user for Subject " + subject);

				ArrayList<String> answers = hmap_answers.get(subject);
				ArrayList<String> studentAnswers = hmap_StudentAnswers.get(subject);

				double matched_ans = 0;
				double no_of_questions = hmap_questions.get(subject).size();
				for (int i = 0; i < answers.size(); i++)
					if (answers.get(i).equals(studentAnswers.get(i)))
						matched_ans++;
				double percentage = ((matched_ans * 100) / no_of_questions);

				System.out.println(subject + " score = " + percentage);
			}
		}
	}
}
