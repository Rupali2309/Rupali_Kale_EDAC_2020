package JavaMiniProject;

import java.util.Scanner;

public class ExaminationMgmtSystem {

	protected static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("*********************************************************");
		System.out.println("*	Welcome to Examination Management System	*");
		System.out.println("*********************************************************");

		Registration rg = new Registration();
		rg.doRegistration();

		Login login = new Login();
		Registration registeredUser = null;
		while (true) {
			if (Login.isUser_logged_in() == false) {
				registeredUser = login.doLogin();
				login.verifyLogin(registeredUser);
			}
			int choice = login.viewOptions(registeredUser);

			switch (choice) {
			case 1:
				if (registeredUser.isAdminUser())
					new Administrator().setExaminationPaper(registeredUser);
				else
					new Student().givePracticeExam();
				break;
			case 2:
				if (registeredUser.isAdminUser())
					new Administrator().addStudent(rg);
				else
					new Student().giveExam();
				break;
			case 3:
				if (registeredUser.isAdminUser())
					new Administrator().removeStudent();
				else
					new Student().viewStudentResult(registeredUser.getName());
				break;
			case 4:
				if (registeredUser.isAdminUser())
					new Administrator().viewStudentResult(registeredUser.getName());
				else
					login.logOutUser(registeredUser);
				break;
			case 5:
				if (registeredUser.isAdminUser())
					login.logOutUser(registeredUser);
				break;
			default:
				System.err.println("WRONG CHOICE!!!!");
				break;
			}

			System.out.println("Do You Want To EXIT?? Y/N");
			if (sc.nextLine().equalsIgnoreCase("y"))
				break;
		}
		sc.close();
	}
}
