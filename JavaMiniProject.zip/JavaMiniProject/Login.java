package JavaMiniProject;

public class Login extends ExaminationMgmtSystem {

	private static boolean user_logged_in = false;
	private String username;

	public Registration doLogin() {
		System.out.println("Enter details for login");
		System.out.println("Enter Email ID of User");
		String email = sc.nextLine().trim();
		System.out.println("Enter password");
		String password = sc.nextLine().trim();

		Registration registeredUser_loggedIn = null;

		boolean userExists = false;
		for (Registration registeredUser : Registration.getRegisteredUsers()) {
			if (registeredUser.getEmail().equals(email) && registeredUser.getPassword().equals(password)) {
				userExists = true;
				setUsername(registeredUser.getName());
				registeredUser_loggedIn = registeredUser;
				break;
			}
		}

		if (!userExists)
			System.out.println("Invalid Email ID Or password for user " + getUsername());
		else
			user_logged_in = true;
		return registeredUser_loggedIn;
	}

	public boolean logOutUser(Registration registeredUser_loggedIn) {
		if (user_logged_in) {
			user_logged_in = false;
			System.out.println(registeredUser_loggedIn.getName() + " logged out successfully");
		} else
			System.out.println(registeredUser_loggedIn.getName() + " is already logged out");

		return user_logged_in;
	}

	public void verifyLogin(Registration registeredUser_loggedIn) {
		if (registeredUser_loggedIn != null)
			System.out.println("Logged in successfully");
		else {
			System.err.println("Failed to login");
			System.exit(0);
		}
	}

	public int viewOptions(Registration registeredUser) {
		if (registeredUser.isAdminUser()) {
			System.out.println(
					"Admin User Options\n1.Set Exam Paper\n2.Add Student\n3.Delete Student\n4.View Student Result\n5.Logout");
		} else {
			System.out.println("\nStudent Options\n1. Give Practice Exam\n2. Give Exam\n3.View Result\n4.Logout");
		}

		return Integer.parseInt(sc.nextLine());
	}

	public static boolean isUser_logged_in() {
		return user_logged_in;
	}

	public String getUsername() {
		return username;
	}

	private void setUsername(String username) {
		this.username = username;
	}

}
