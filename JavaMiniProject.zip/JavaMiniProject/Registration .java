package JavaMiniProject;

import java.util.ArrayList;

 class Registration extends ExaminationMgmtSystem {

	public static ArrayList<Registration> registeredUsers = new ArrayList<>();
	private String name;
	private String lastName;
	private String email;
	private String password;
	private boolean adminUser;

	public void doRegistration() {
		boolean repeat = true;
		while (repeat) {
			System.out.println("Registration is in progress...");

			Registration rg = new Registration();

			System.out.println("Enter Name : ");
			rg.setName(sc.nextLine());

			System.out.println("Enter Last Name : ");
			rg.setLastName(sc.nextLine());

			System.out.println("Enter Email ID");
			rg.setEmail(sc.nextLine());

			System.out.println("Enter Password");
			rg.setPassword(sc.nextLine());

			System.out.println("Press Y/y if user is Admin user else press N/n or any character");
			if (sc.nextLine().trim().equalsIgnoreCase("y"))
				rg.setAdminUser(true);
			else
				rg.setAdminUser(false);
			registeredUsers.add(rg);
			System.out.println("Registration Done for " + rg.getName());
			rg = null;
			System.out.println("\nDo you want to Register more users?? Press Y/y if Yes or Press N/n to exit");
			if (sc.nextLine().trim().equalsIgnoreCase("n"))
				break;
		}
		System.out.println("Printing All Registered Users");

		for (Registration rg : registeredUsers) {
			System.out.println(rg.toString());
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAdminUser() {
		return adminUser;
	}

	public void setAdminUser(boolean adminUser) {
		this.adminUser = adminUser;
	}

	public static ArrayList<Registration> getRegisteredUsers() {
		return registeredUsers;
	}
	
	@Override
	public String toString() {
		return "Registration [name=" + name + ", lastName=" + lastName + ", email=" + email + ", password=" + password
				+ ", adminUser=" + adminUser + "]";
	}
}
