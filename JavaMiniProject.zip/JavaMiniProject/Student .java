package JavaMiniProject;

import java.util.ArrayList;

 class Student extends Examination {

	public void giveExam() {
		exam();
	}

	public void givePracticeExam() {
		exam();
	}

	private void exam() {

		hmap_StudentAnswers.clear();

		System.out.println("Select Subject to give exam");
		int counter = 1;

		ArrayList<String> subjects = new ArrayList<>();
		for (String subject : hmap_questions.keySet())
			subjects.add(subject);

		System.out.println("Enter Choice :");
		for (int i = 1; i <= subjects.size(); i++)
			System.out.println(i + ". " + subjects.get(i - 1));

		int choice = (Integer.parseInt(sc.nextLine()) - 1);
		String subject = subjects.get(choice);
		ArrayList<ArrayList<String>> choices = hmap_choices.get(subject);

		System.out.println("Selected Subject : " + subject);

		ArrayList<String> studentAnswers = new ArrayList<>();
		counter = 1;
		for (String question : hmap_questions.get(subject)) {
			System.out.println("Question " + counter + "\n" + question);

			int option_number = 1;
			for (String ch : choices.get(counter - 1)) {
				System.out.println(option_number + ". " + ch);
				option_number = option_number + 1;
			}

			System.out.println("Select correct answer : ");
			studentAnswers.add(choices.get(counter - 1).get((Integer.parseInt(sc.nextLine())) - 1));
			counter++;
		}

		hmap_StudentAnswers.put(subject, studentAnswers);
		System.out.println("Student gave following answers");
		System.out.println(hmap_StudentAnswers);
	}

}
