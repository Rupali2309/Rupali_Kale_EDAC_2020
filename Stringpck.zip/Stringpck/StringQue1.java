package Stringpck;

class StringQue1
{
public static void main(String []args)
{
String str="Hello world 37 1!";
int countVowels=0;
int countConsonants=0;
int countNumber=0;
int countOther=0;

str=str.toLowerCase();

for(int i=0;i<str.length();i++)
{
if(str.charAt(i)=='a' ||str.charAt(i)=='e' || str.charAt(i)=='i' || str.charAt(i)=='o' ||str.charAt(i)=='u')
{
 countVowels++;
}
else if(str.charAt(i)>'a' && str.charAt(i)<'z')
{
   countConsonants++;
}
else if(str.charAt(i)>'0' && str.charAt(i)<'9')
{
    countNumber++;
    
}
else if(str.charAt(i)==' ' || str.charAt(i)=='!' || str.charAt(i)=='"')
{
countOther++;
}

}
System.out.println(countVowels);
System.out.println(countConsonants);
System.out.println(countNumber);
System.out.println(countOther);

}
}