package Stringpck;
import java.util.Scanner;
class StringQue6
{
public static void main(String[]args)
{
    
    
Scanner sc=new Scanner(System.in);
String str=sc.nextLine();
int start=sc.nextInt();
int end=sc.nextInt();
String s1=str.substring(start,end);
 s1=str.substring(start, end);

if(s1==(s1))
{
System.out.println(true);
}
    else
    System.out.println(false);
}
}