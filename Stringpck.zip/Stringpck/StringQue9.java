package Stringpck;
import java.util.Scanner;
class StringQue9
{
    
public static void main(String[] args)
{ 
    Scanner sc=new Scanner(System.in);
    String str1=sc.nextLine();
    String str2=sc.nextLine();
    
    for(int i=0;i<str1.length();i++)
    {
    int count=0;
    for(int j=0;j<str2.length();j++)
    {
    if(str1.charAt(i)==str2.charAt(j))
        count++;
    }
    }
 
}
}