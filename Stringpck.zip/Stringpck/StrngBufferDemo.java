package Stringpck;
import java.util.Scanner;


import java.io.*; 
class GFG { 
    
    public static void main(String[] args) 
    { 
//        StringBuffer s = new StringBuffer("GeeksforGeeks"); 
//        int p = s.length(); 
//        int q = s.capacity(); 
//        System.out.println("Length of string GeeksforGeeks=" + p); 
//        System.out.println("Capacity of string GeeksforGeeks=" + q); 
//        
        
        
        Scanner scan = new Scanner(System.in);
        String s = scan.nextLine();
        String arr[]=s.split("\\s");
        for(int i=0;i<arr.length-1;i++){
            System.out.println(arr[i]);
        }
    } 
} 


