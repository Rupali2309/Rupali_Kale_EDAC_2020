package RoughWork;
import java.util.*;

class RealComplex
{
int real;
double complex;

RealComplex(int r,double c)
{
 this.real=r;
 this.complex=c;

}

public static RealComplex realComplexSum(RealComplex c1,RealComplex c2)
{
   int sum=0;
   RealComplex rc=new RealComplex(0,0);
   rc.real=c1.real+c2.real;
   rc.complex=c1.complex+c2.complex;
   return rc;
  
}

public static void main(String []args)
{
  RealComplex rc1=new RealComplex(11,23.4);
  RealComplex rc2=new RealComplex(12,45.6);  
  RealComplex temp = realComplexSum(rc1, rc2);
        System.out.printf("Sum is: "+ temp.real+" + "+ temp.complex +"i");
  ;
    
}

}


